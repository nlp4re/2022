## Organising Committee

*   Fabiano Dalpiaz, Utrecht University, The Netherlands. 
*   Alessio Ferrari, Consiglio Nazionale delle Ricerche, Istituto di Scienza e Tecnologie dell’Informazione “A. Faedo’’ (CNR-ISTI), Italy. 
*   Xavier Franch, Universitat Politècnica de Barcelona (UPC-BarcelonaTech), Spain.
*   Cristina Palomares, Universitat Politècnica de Barcelona (UPC-BarcelonaTech), Spain.

## NLP Tool Showcase Committee

*   Frank Houdek, Daimler AG, Germany
*   Sarah Gregory, Intel, USA

## Program Committee

*   Daniel M. Berry, University of Waterloo, Canada
*   Frederik Simon Bäumer, Paderborn University, Germany
*   Jörg Dörr, Fraunhofer IESE, Germany
*   Felice Dell'Orletta, ILC-CNR, Italy
*   Tejaswini Deoskar, Utrecht University, Netherlands
*   Henning Femmer, Technical University of Munich, Germany
*   Davide Fucci, University of Hamburg, Germany
*   Vincenzo Gervasi, University of Pisa, Italy
*   Eduard Groen, Fraunhofer IESE, Germany
*   Emitzá Guzmán, University of Zurich, Switzerland
*   Anas Mahmoud, Louisiana State University, USA
*   Daniel Méndez, Technical University of Munich, Germany
*   Luisa Mich, University of Trento, Italy
*   Itzel Morales Ramírez, Infotec, Mexico
*   Barbara Paech, University of Heidelberg, Germany
*   Anna Perini, FBK, Italy
*   Mehrdad Sabetzadeh, University of Luxembourg, Luxembourg
*   Nicolas Sannier, University of Luxembourg, Luxembourg
*   Norbert Seyff, University of Zurich and University of Applied Sciences and Arts Northwestern, Switzerland
*   Zahra Shakeri Hossein Abad, University of Calgary, Canada
*   Daniel Töws, Fraunhofer FKIE, Germany
*   Reut Tsarfaty, Open University, Israel
*   Michael Unterkalmsteiner, Blekinge Institute of Technology, Sweden
*   Han van der Aa, Humboldt University of Berlin, Germany
*   Andreas Vogelsang, TU Berlin, Germany
*   Liping Zhao, University of Manchester, UK