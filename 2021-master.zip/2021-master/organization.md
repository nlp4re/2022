---
# Feel free to add content and custom Front Matter to this file.

layout: default
title: NLP4RE Organization
---

## Organizing Committee
&nbsp;
* Sallam Abualhaija, University of Luxembourg, Luxembourg
* Fatma Başak Aydemir, Boğaziçi University, Turkey
* Alessio Ferrari, CNR-ISTI, Italy
* Jin Guo, McGill University, Canada

&nbsp;

## Program Committee
&nbsp;
- Chetan Arora, Deakin University, Australia
- Dan Berry, University of Waterloo, Canada
- Andrea Cimino, Istituto di Linguistica Computazionale, Italy
- Fabiano Dalpiaz, Utrecht University, Netherlands
- Henning Femmer, Qualicen GmbH, Germany
- Xavier Franch, Universitat Politècnica de Catalunya, Spain
- Davide Fucci, HITec, University of Hamburg, Germany
- Vincenzo Gervasi, University of Pisa, Italy
- Sepideh Ghanavati, University of Maine, USA
- Stefania Gnesi, ISTI-CNR, Italy
- Eduard Groen, Fraunhofer, Germany
- Frank Houdek, Daimler Ag, Germany
- Luisa Mich, University of Trento, Italy
- Lloyd Montgomery, University of Hamburg, Germany
- Nan Niu, University of Cincinnati, USA
- Barbara Paech, Universität Heidelberg, Germany
- Simon Andre Scherr, Fraunhofer, Germany
- Michael Unterkalmsteiner, Blekinge Institute of Technology, Sweden
- Andreas Vogelsang, University of Cologne, Germany
- Liping Zhao, University of Manchester, UK
- Han van der Aa, University of Mannheim, Germany
